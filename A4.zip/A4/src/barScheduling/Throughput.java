package barScheduling;

import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

public class Throughput implements Runnable {
    private AtomicInteger counter = new AtomicInteger();

    public Throughput(AtomicInteger counter) {
        this.counter = counter;
    }

    public void run() {
        try {
            FileWriter fileW = new FileWriter("throughput" + SchedulingSimulation.getSched() + ".txt", true);
            fileW.write(Integer.toString(counter.get()) + "\n");
            fileW.close();
            counter.set(0);
        } catch (IOException e) {
            System.out.println(e);
        }
    }
}