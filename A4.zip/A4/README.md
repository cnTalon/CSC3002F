To run the SchedulingSimulation in Unix or Windows with WSL or SSH:
1. Open the Linux terminal
2. Find the Program folder
3. Type 'make run ARGS="noPatrons 0" for FCFS algorithm or replace 0 with 1 for SJF or 'make run' to run default
4. Hit 'Enter'

To the the SchedulingSimulation on a Windows machine on VSCode:
1. Open a new terminal on the folder
2. Type in 'java -cp bin barScheduling.SchedulingSimulation noPatrons 0' for FCFS algorithm or replace 0 with 1 for SJF or 'jave -cp bin barScheduling.SchedulingSimulation' to run default
3. Hit 'Enter'